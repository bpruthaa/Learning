import pyautogui
pyautogui.moveTo(100, 150) #Move mouse pointer
