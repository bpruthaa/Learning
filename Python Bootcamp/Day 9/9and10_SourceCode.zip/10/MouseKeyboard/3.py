import pyautogui
pyautogui.click()
